import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:myfood/PhotoScroller.dart';
import 'package:myfood/clases/Restaurante.dart';
import 'package:myfood/clases/menu.dart';

import '../RaisedGradientButton.dart';
import 'lista_productos.dart';

class DetalleRestaurantePage extends StatefulWidget {
  DetalleRestaurantePage({Key key, String title}) : super(key: key);

  @override
  _DetalleRestaurantePage createState() => _DetalleRestaurantePage();
}

class _DetalleRestaurantePage extends State<DetalleRestaurantePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('MyFood - Restaurante'), actions: makeMenu(context)),
      body: SingleChildScrollView(
        child: FutureBuilder(
            builder: (context, snapshot) {
              List rest = jsonDecode(snapshot.data.toString());
              Restaurante restaurante = Restaurante(
                  rest[0]["foto"],
                  rest[0]["titulo"],
                  rest[0]["descripcion"],
                  (rest[0]["fotos_productos"] as List<dynamic>)
                      .cast<String>()
                      .toList());
              return DetalleRestaurante(restaurante);
            },
            future: DefaultAssetBundle.of(context)
                .loadString("assets/restaurantes.json")),
      ),
    );
  }
}

class DetalleRestaurante extends StatelessWidget {
  Restaurante restaurante;
  DetalleRestaurante(this.restaurante);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: EdgeInsets.all(5),
          child: Image.asset("imagenes/${restaurante.foto}"),
        ),
        Padding(
          padding: EdgeInsets.all(5),
          child: Text(restaurante.titulo,
              softWrap: false,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 28.0,
                  color: const Color(0xffff0000),
                  fontWeight: FontWeight.w600,
                  fontFamily: "Roboto")),
        ),
        Padding(
            padding: EdgeInsets.all(15),
            child: Text(
              restaurante.descripcion,
              style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                  fontFamily: "Roboto"),
            )),
        PhotoScroller(restaurante.fotosProductos, "Nuestros productos"),
        Padding(
          padding: const EdgeInsets.only(top: 20, bottom: 20),
          child: RaisedGradientButton(
              height: 50,
              width: 300,
              child: Text(
                "Ver lista de platos",
                style: TextStyle(
                    color: Colors.black87,
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700),
              ),
              gradient: LinearGradient(
                colors: <Color>[Colors.red, Colors.red[50]],
              ),
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ListaProductosPage()));
              }),
        )
      ],
    );
  }
}
