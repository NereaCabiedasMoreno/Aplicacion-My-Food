
import 'package:flutter/material.dart';
import 'package:myfood/rutas/inicio.dart';

import '../RaisedGradientButton.dart';

class LoginPage extends StatefulWidget {
  LoginPage({Key key, String title}) : super(key: key);
  @override
  _LoginPageState createState() => new _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
        appBar: AppBar(
          title: Text('MyFood'),
        ),
        body: Stack(
          children: <Widget>[
            Opacity(
              opacity: 0.25,
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("imagenes/fondo.jpg"),
                      fit: BoxFit.cover,
                    ),
                    color: Colors.black.withAlpha(90)),
              ),
            ),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.fromLTRB(50.0, 1.0, 50.0, 1.0),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Image.asset(
                      // Logo
                      'imagenes/MyFoodAPP.png',
                      height: 100.0,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0, top: 32.0),
                      child: new Text(
                        "Índica tu nombre de usuario y contraseña:",
                        style: new TextStyle(
                            fontSize: 20.0,
                            color: const Color(0xffff0000),
                            fontWeight: FontWeight.w600,
                            fontFamily: "Roboto"),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: TextField(
                        obscureText: false,
                        decoration: InputDecoration(
                          enabledBorder: new OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black),
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(10.0),
                            ),
                          ),
                          labelText: 'Username',
                          labelStyle: TextStyle(
                              fontSize: 20.0,
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w800,
                              fontFamily: "Roboto"),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                          enabledBorder: new OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black),
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(10.0),
                            ),
                          ),
                          labelText: 'Password',
                          labelStyle: TextStyle(
                              fontSize: 20.0,
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w800,
                              fontFamily: "Roboto"),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: RaisedGradientButton(
                          child: Text(
                            'Entrar',
                            style: TextStyle(
                                color: Colors.black87, fontSize: 20.0),
                          ),
                          gradient: LinearGradient(
                            colors: <Color>[Colors.red, Colors.red[100]],
                          ),
                          borderRadius: 10,
                          onPressed: () {
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        InicioPage()));
                          }),
                    )
                  ]),
            ),
          ],
        ));
  }

  void buttonPressed() {}
}
