import 'package:flutter/material.dart';
import 'package:myfood/clases/menu.dart';

import '../RaisedGradientButton.dart';

class ListaPedidosPage extends StatefulWidget {
  ListaPedidosPage({Key key, String title}) : super(key: key);

  @override
  _ListaPedidosPage createState() => _ListaPedidosPage();
}

class _ListaPedidosPage extends State<ListaPedidosPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MyFood - Mis pedidos"),
        actions: makeMenu(context),
      ),
      body: SingleChildScrollView(
          padding: const EdgeInsets.all(15),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Tus pedidos",
                  style: new TextStyle(
                      fontSize: 30.0,
                      color: const Color(0xffff0000),
                      fontWeight: FontWeight.w600,
                      fontFamily: "Roboto"),
                ),
                Divider(
                  color: Colors.red,
                ),
                makePedido(context, "Domingo, 26 de mayo de 2019",
                    ["2 x Plato de pita"], "30,00 €"),
                makePedido(
                    context,
                    "Jueves, 23 de mayo de 2019",
                    [
                      "1 x Bocadillo de carne",
                      "1 x Rollitos con tomate",
                      "1 x Pizza cuatro quesos"
                    ],
                    "23,50 €"),
                makePedido(
                    context,
                    "Lunes, 20 de mayo de 2019",
                    ["1 x Tallarines con carne", "2 x Rollitos con tomate"],
                    "15,20 €"),
              ],
            ),
          )),
    );
  }
}

Widget makePedido(
    BuildContext context, String fecha, List<String> platos, String total) {
  List<Widget> _platos = List<Widget>();

  for (var plato in platos) {
    _platos.add(Column(crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          plato,
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w400),
        ),
        Divider(
          indent: 50,
          color: Colors.red[300],
        )
      ],
    ));
  }

  return Padding(
      padding: const EdgeInsets.all(10),
      child: SizedBox(
        width: 400,
        child: Card(
          color: Colors.grey[200],
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text(fecha,
                    style: TextStyle(
                        color: Colors.red,
                        fontSize: 20,
                        fontWeight: FontWeight.w600)),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Column(
                  children: _platos,
                  crossAxisAlignment: CrossAxisAlignment.start,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  "Total: $total",
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 20,
                      fontWeight: FontWeight.w600),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: RaisedGradientButton(
                    height: 20,
                    width: 150,
                    child: Text("Volver a pedir"),
                    gradient: LinearGradient(
                      colors: <Color>[Colors.red, Colors.red[50]],
                    ),
                    onPressed: () {
                      showDialog<void>(
                          context: context,
                          barrierDismissible:
                              false, // El usuario debe pulsar en el botón para salir
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text("MyFood - Pedidos"),
                              content: Text(
                                  "¿Estás seguro de que quieres volver a realizar el pedido? Es posible que se realicen cargos extras según variación de precios."),
                              actions: <Widget>[
                                FlatButton(
                                  child: Text(
                                    "Sí",
                                    style: TextStyle(fontSize: 20),
                                  ),
                                  onPressed: () {},
                                ),
                                FlatButton(
                                  child: Text("No"),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                )
                              ],
                            );
                          });
                    }),
              )
            ],
          ),
        ),
      ));
}
