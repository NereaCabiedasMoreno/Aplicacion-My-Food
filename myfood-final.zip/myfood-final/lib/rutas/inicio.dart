import 'package:flutter/material.dart';
import 'package:myfood/clases/menu.dart';
import 'package:myfood/rutas/lista_pedidos.dart';
import 'package:myfood/rutas/lista_productos.dart';
import 'package:myfood/rutas/lista_restaurantes.dart';

import '../PhotoScroller.dart';
import '../RaisedGradientButton.dart';

class InicioPage extends StatefulWidget {
  InicioPage({Key key, String title}) : super(key: key);

  @override
  _InicioPage createState() => new _InicioPage();
}

class _InicioPage extends State<InicioPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MyFood - Usuario"),
        actions: makeMenu(context),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Bienvenido, Juan",
              style: new TextStyle(
                  fontSize: 30.0,
                  color: const Color(0xffff0000),
                  fontWeight: FontWeight.w600,
                  fontFamily: "Roboto"),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: RaisedGradientButton(
                  width: 300,
                  child: Text(
                    'Ver tus pedidos recientes',
                    style: TextStyle(color: Colors.black87, fontSize: 20.0),
                  ),
                  gradient: LinearGradient(
                    colors: <Color>[Colors.red, Colors.red[100]],
                  ),
                  borderRadius: 10,
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ListaPedidosPage()));
                  }),
            ),
            Divider(
              color: Colors.red,
            ),
            PhotoScroller(["rest1.jpg", "rest2.jpg", "rest3.jpg", "rest4.jpg"],
                "Tus restaurantes"),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: RaisedGradientButton(
                  width: 300,
                  child: Text(
                    'Ver todos los restaurantes',
                    style: TextStyle(color: Colors.black87, fontSize: 20.0),
                  ),
                  gradient: LinearGradient(
                    colors: <Color>[Colors.red, Colors.red[100]],
                  ),
                  borderRadius: 10,
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ListaRestaurantesPage()));
                  }),
            ),
            Divider(
              color: Colors.red,
            ),
            PhotoScroller(
                ["plato11.jpg", "plato22.jpg", "plato33.jpg", "plato44.jpg"],
                "Tus últimos pedidos"),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: RaisedGradientButton(
                  width: 300,
                  child: Text(
                    'Ver todos los platos',
                    style: TextStyle(color: Colors.black87, fontSize: 20.0),
                  ),
                  gradient: LinearGradient(
                    colors: <Color>[Colors.red, Colors.red[100]],
                  ),
                  borderRadius: 10,
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ListaProductosPage()));
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
