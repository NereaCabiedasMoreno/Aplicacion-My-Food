import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:myfood/clases/Restaurantes.dart';
import 'package:myfood/clases/Restaurante.dart';
import 'dart:convert';

import 'package:myfood/clases/menu.dart';

class ListaRestaurantesPage extends StatefulWidget {
  ListaRestaurantesPage({Key key, String title}) : super(key: key);

  @override
  _ListaRestaurantesPage createState() => _ListaRestaurantesPage();
}

class _ListaRestaurantesPage extends State<ListaRestaurantesPage> {
  @override
  Widget build(BuildContext context) {
    var restaurantes = List<Restaurante>();

    return Scaffold(
        appBar: AppBar(
            title: Text('MyFood - Restaurantes'), actions: makeMenu(context)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: TextField(
              decoration: InputDecoration(
                enabledBorder: new OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[500]),
                  borderRadius: const BorderRadius.all(
                    const Radius.circular(10.0),
                  ),
                ),
                labelText: "Buscar Restaurante",
              ),
            ),
          ),
          FutureBuilder(
            builder: (context, snapshot) {
              List rest = jsonDecode(snapshot.data.toString());
              for (var item in rest) {
                restaurantes.add(Restaurante(
                    item["foto"],
                    item["titulo"],
                    item["descripcion"],
                    (item["fotos_productos"] as List<dynamic>)
                        .cast<String>()
                        .toList()));
              }

              return Flexible(child: ListaRestaurantes(restaurantes));
            },
            future: DefaultAssetBundle.of(context)
                .loadString("assets/restaurantes.json"),
          )
        ]));
  }
}
