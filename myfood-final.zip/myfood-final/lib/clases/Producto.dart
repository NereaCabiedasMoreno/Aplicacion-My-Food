class Producto
{
  String foto;
  String titulo;
  String texto;
  String precio;

  Producto(this.foto, this.titulo, this.texto, this.precio);
}