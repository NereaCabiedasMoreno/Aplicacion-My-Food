import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:myfood/rutas/inicio.dart';
import 'package:myfood/rutas/lista_productos.dart';
import 'package:myfood/rutas/lista_restaurantes.dart';
import 'package:myfood/rutas/login.dart';

enum PageRoutes { ListaRestaurantes, ListaProductos, Exit }

List<Widget> makeMenu(BuildContext context) {
  return <Widget>[
    IconButton(
      icon: Icon(Icons.account_circle),
      onPressed: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => InicioPage()));
      },
    ),
    PopupMenuButton<PageRoutes>(
      onSelected: (PageRoutes value) {
        switch (value) {
          case PageRoutes.ListaRestaurantes:
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ListaRestaurantesPage()));
            break;
          case PageRoutes.ListaProductos:
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => ListaProductosPage()));
            break;
          case PageRoutes.Exit:
            showDialog<void>(
                context: context,
                barrierDismissible:
                    false, // El usuario debe pulsar en el botón para salir
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text("MyFood - Salir"),
                    content: Text("¿Estás seguro de que quieres salir?"),
                    actions: <Widget>[
                      FlatButton(
                        child: Text(
                          "Sí",
                        ),
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LoginPage()),
                              (Route<dynamic> route) => false);
                        },
                      ),
                      FlatButton(
                        child: Text("No", style: TextStyle(fontSize: 20)),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )
                    ],
                  );
                });

            break;
        }
      },
      itemBuilder: (BuildContext context) {
        return [
          PopupMenuItem<PageRoutes>(
              value: PageRoutes.ListaRestaurantes, child: Text("Restaurantes")),
          PopupMenuItem<PageRoutes>(
              child: Text("Productos"), value: PageRoutes.ListaProductos),
          PopupMenuItem<PageRoutes>(
              child: Text("Salir"), value: PageRoutes.Exit)
        ];
      },
    )
  ];
}
